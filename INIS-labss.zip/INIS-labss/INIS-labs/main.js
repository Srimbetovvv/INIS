let initProducts = () => {
  const body = document.querySelector("body");
  body.innerHTML = `
    <header class="header">
      <div class="header__blue-line"></div>
      <div class="header__title-wrapper">
        <div class="header__title">
          <div class="logo">
            <a href="index.html"
              ><img class="logo__img"
                src="./site_images/logo.png"
                alt="logo"
            /></a>
          </div>
          <h1 class="title-name">Инженерная психология (ИНИС)</h1>
        </div>
      </div>
      <nav class="header__nav-bar">
        <a class="header__nav-link" href="products.html">T-shirts</a>
        <a class="header__nav-link" href="not_implemented.html">Hoodies</a>
        <a class="header__nav-link" href="not_implemented.html">Create Your own</a>
        <a class="header__nav-link" href="not_implemented.html">About Us</a>
        <a class="header__nav-link" href="not_implemented.html">Your Account</a>
      </nav>
    </header>
    <main class="main-content">
      <h2 class="page-name">Our T-Shirts</h2>
      <div class="products-collection"></div>
    </main>
    <div class="quick-view"></div>
    <footer class="footer">
      <nav class="footer__nav-bar">
        <a class="footer__nav-link" href="not_implemented.html">Contact Us</a>
        <a class="footer__nav-link" href="not_implemented.html">Site Map</a>
        <a class="footer__nav-link" href="not_implemented.html">Privacy Police</a>
        <a class="footer__nav-link" href="not_implemented.html">Careers</a>
        <a class="footer__nav-link" href="not_implemented.html">Reviews</a>
      </nav>
    </footer>
   `;

  const productsCollection = document.querySelector(".products-collection");
  shirts.map((shirt) => {
    const productsCollectionElement = document.createElement("div");
    productsCollectionElement.innerHTML = `
      <div class="shirt">
        <div class="shirt__image">
          <button value="${
            shirt.name
          }" onclick="handleRedirectToDetails(this.value)"><img src="${
      shirt.colors.white.front
    }" alt="shirt-front"/></button>
        </div>
        <h3 class="shirt__name">${shirt.name}</h3>
        <p class="shirt__count-of-colors">Available in ${
          Object.values(shirt.colors).length
        } colors</p>
        <div class="shirt__nav-bar">
          <div class="shirt__buttons">
            <button value="${
              shirt.name
            }" onclick="handleQuickView(this.value)" class="shirt__button">Quick View</button>
            <button value="${
              shirt.name
            }" onclick="handleRedirectToDetails(this.value)" class="shirt__button">See Page</button>
          </div>  
        </div>
      </div>          
    `;

    productsCollection.append(productsCollectionElement);
  });
};

const handleRedirectToDetails = (shirtName) => {
  localStorage.setItem("currentShirtName", shirtName);
  document.location = "./details.html";
};

const handleQuickView = (shirtName) => {
  const previousQuickView = document.querySelector(".quick-view-wrapper");
  if (previousQuickView) {
    handleCloseQuickView();
  }

  localStorage.setItem("SHIRT_IN_QUICK_VIEW", shirtName);
  const currentShirtName = localStorage.getItem("SHIRT_IN_QUICK_VIEW");
  const currentShirt = shirts.filter(
    (shirt) => shirt.name === currentShirtName
  )[0];
  const quickView = document.querySelector(".quick-view");

  const quickViewWrapper = document.createElement("div");
  quickViewWrapper.className = "quick-view-wrapper";
  quickViewWrapper.innerHTML = `
    <div class="shirt-sides">
      <div class="shirt-side">
        <img src="${currentShirt.colors.white.front}" alt="shirt-front"/>
      </div>
      <div class="shirt-side">
        <img src="${currentShirt.colors.white.back}" alt="shirt-back"/>
      </div>
    </div>
    <div class="quick-info">
      <div class="quick-name">${currentShirt.name}</div>
      <div class="quick-price">${currentShirt.price}</div>
      <button onclick="handleCloseQuickView()" class="close-button">Close</button>
    </div>
  `;

  quickView.append(quickViewWrapper);
};

const handleCloseQuickView = () => {
  const quickViewWrapper = document.querySelector(".quick-view-wrapper");
  quickViewWrapper.remove();
};

let initDetails = () => {
  localStorage.setItem("SIDE", "front");
  localStorage.setItem("COLOR", "white");
  const shirtName = localStorage.getItem("currentShirtName");
  const currentShirt = shirts.filter((shirt) => shirt.name === shirtName)[0];

  const body = document.querySelector("body");
  body.innerHTML = `
    <header class="header">
      <div class="header__blue-line"></div>
      <div class="header__title-wrapper">
        <div class="header__title">
          <div class="logo">
            <a href="index.html"
              ><img class="logo__img"
                src="./site_images/logo.png"
                alt="logo"
            /></a>
          </div>
          <h1 class="title-name">Инженерная психология (ИНИС)</h1>
        </div>
      </div>
      <nav class="header__nav-bar">
        <a class="header__nav-link" href="products.html">T-shirts</a>
        <a class="header__nav-link" href="not_implemented.html">Hoodies</a>
        <a class="header__nav-link" href="not_implemented.html">Create Your own</a>
        <a class="header__nav-link" href="not_implemented.html">About Us</a>
        <a class="header__nav-link" href="not_implemented.html">Your Account</a>
      </nav>
    </header>
    <main class="main-content">
      <h2 class="page-name current-shirt-name">${currentShirt.name}</h2>
      <div class="product-info"></div>
    </main>
    <footer class="footer">
      <nav class="footer__nav-bar">
        <a class="footer__nav-link" href="not_implemented.html">Contact Us</a>
        <a class="footer__nav-link" href="not_implemented.html">Site Map</a>
        <a class="footer__nav-link" href="not_implemented.html">Privacy Police</a>
        <a class="footer__nav-link" href="not_implemented.html">Careers</a>
        <a class="footer__nav-link" href="not_implemented.html">Reviews</a>
      </nav>
    </footer>
   `;

  const productInfo = document.querySelector(".product-info");
  productInfo.innerHTML = `
      <div class="current-shirt">
        <div class="current-shirt__image">
          <img class="shirt-image" src="${
            currentShirt?.colors?.white?.front
          }" alt="current-shirt-image"/>
        </div>
        <div class="current-shirt__info">
          <h3 class="current-shirt__price">${
            currentShirt?.price ? currentShirt?.price : "No price"
          }</h3>
          <p class="current-shirt__description">${
            currentShirt?.description
              ? currentShirt?.description
              : "No description"
          }</p>
          <div class="side">
            Side:
            <div class="side__buttons">
              <button onclick="handleChangeSide('front')" class="side__button">Front</button>
              <button onclick="handleChangeSide('back')" class="side__button">Back</button>
            </div>  
          </div>
          <div class="color">
            Color:
            <div class="color__buttons"></div>
          </div>
        </div>
      </div>          
    `;

  const colorButtons = document.querySelector(".color__buttons");
  if (Object.keys(currentShirt.colors)) {
    Object.keys(currentShirt.colors).map((color) => {
      const colorButton = document.createElement("div");
      colorButton.innerHTML = `
        <button 
          value="${color}"
          onclick="handleChangeColor(this.value)" 
          class="color__button" 
          style="background: ${color}; color: ${
        color === "blue" ? "white" : "#0d193f"
      }"
        >
          ${color}
        </button>
      `;

      colorButtons.append(colorButton);
    });
  } else colorButtons.append("<div>No colors</div>");
};

const handleChangeSide = (side) => {
  const color = localStorage.getItem("COLOR");
  const shirtName = localStorage.getItem("currentShirtName");
  const currentShirt = shirts.filter((shirt) => shirt.name === shirtName)[0];
  const shirtImage = document.querySelector(".shirt-image");
  shirtImage.src = currentShirt.colors[color][side];
  localStorage.setItem("SIDE", side);
};

const handleChangeColor = (currentColor) => {
  const side = localStorage.getItem("SIDE");
  const shirtName = localStorage.getItem("currentShirtName");
  const currentShirt = shirts.filter((shirt) => shirt.name === shirtName)[0];
  const shirtImage = document.querySelector(".shirt-image");
  const COLORS = currentShirt.colors;
  Object.keys(COLORS)
    .filter((color) => color === currentColor)
    .map((color) => {
      shirtImage.src = COLORS[color][side];
    });
  localStorage.setItem("COLOR", currentColor);
};
