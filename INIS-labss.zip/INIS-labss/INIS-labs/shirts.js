var shirts = [
  {
    name: "Beep Boop",
    description: "Type funny sentence.",
    price: "$19.99",
    colors: {
      white: {
        front: "shirt_images/beepboop-white-front.png",
        back: "shirt_images/beepboop-white-back.png",
      },
      blue: {
        front: "shirt_images/beepboop-blue-front.png",
        back: "shirt_images/beepboop-blue-back.png",
      },
      pink: {
        front: "shirt_images/beepboop-pink-front.png",
        back: "shirt_images/beepboop-pink-back.png",
      },
      red: {
        front: "shirt_images/beepboop-red-front.png",
        back: "shirt_images/beepboop-red-back.png",
      },
    },
    default: {
      front: "shirt_images/default-m-front.png",
      back: "shirt_images/default-m-back.png",
    },
  },
  {
    name: "Car",
    description: "Type funny sentence.",
    price: "$10.99",
    colors: {
      white: {
        front: "shirt_images/car-white-front.png",
        back: "shirt_images/car-white-back.png",
      },
      blue: {
        front: "shirt_images/car-blue-front.png",
        back: "shirt_images/car-blue-back.png",
      },
      green: {
        front: "shirt_images/car-green-front.png",
        back: "shirt_images/car-green-back.png",
      },
      yellow: {
        front: "shirt_images/car-yellow-front.png",
        back: "shirt_images/car-yellow-back.png",
      },
      red: {
        front: "shirt_images/car-red-front.png",
        back: "shirt_images/car-red-back.png",
      },
    },
    default: {
      front: "shirt_images/default-w-front.png",
      back: "shirt_images/default-w-back.png",
    },
  },
  {
    name: "Forever Plaid",
    price: "$13.99",
    description: "Type funny sentence.",
    colors: {
      white: {
        front: "shirt_images/plaid-white-front.png",
        back: "shirt_images/plaid-white-back.png",
      },
      pink: {
        front: "shirt_images/plaid-pink-front.png",
        back: "shirt_images/plaid-pink-back.png",
      },
    },
    default: {
      front: "shirt_images/default-w-front.png",
      back: "shirt_images/default-w-back.png",
    },
  },
  {
    name: "BSUIR",
    description:
      "BSUIR mission is to train engineers and scientists capable of generating and implementing innovative ideas, creating competitive high technology products in the spheres of computer science and electronics.",
    price: "$6.99",
    colors: {
      white: {
        front: "shirt_images/bsuir-white-back.png",
        back: "shirt_images/bsuir-white-front.png",
      },
    },
    default: {
      front: "shirt_images/default-m-front.png",
      back: "shirt_images/default-m-back.png",
    },
  },
];
