# INIS-firstlab
Свердлов Родион 910101
https://rodionsverdloval.github.io/INIS-firstlab/
